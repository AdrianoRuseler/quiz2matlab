
% Process data 
%  circuit.FFTDATA = power_fftscope(circuit.PSIMCMD.data);

function  dataout = datacmd(datain)


x=Va+Vb;